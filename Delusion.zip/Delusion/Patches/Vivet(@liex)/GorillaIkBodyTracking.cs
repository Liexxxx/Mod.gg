﻿using GorillaTagScripts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Delusion.Patches.Vivet__liex_
{
    internal class GorillaIkBodyTracking
    {
        [HarmonyLib.HarmonyPatch(typeof(GorillaIK), nameof(GorillaIK.CheckPermissions))]
        public class PermissionChk
        {
            public static bool Prefix() => Config.GorillaIkBodyTrackingPermissions;
        }
        [HarmonyLib.HarmonyPatch(typeof(SubscriptionManager), nameof(SubscriptionManager.IsLocalSubscribed))]
        public class AlwaysSubscribed
        {
            public static bool Prefix() => Config.FreeIkSubscriptions;
        }
    }
}
