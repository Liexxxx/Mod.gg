﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace Delusion.Patches.Vivet__liex_
{
    [HarmonyLib.HarmonyPatch(typeof(SIPlayer), nameof(SIPlayer.PlayerKnockback))]
    internal class SuperInfectionKnockBack
    {
        public static bool Prefix(Vector3 directionAndMagnitude, bool forceOffGround = true, bool applyExclusionZone = true) => Config.SuperInfectionKnockBack;
    }
}
