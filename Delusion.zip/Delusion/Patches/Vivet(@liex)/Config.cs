﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Delusion.Patches.Vivet__liex_
{
    internal class Config
    {
        public static bool SuperInfectionKnockBack = false;
        public static bool GorillaIkBodyTrackingPermissions = false;
        public static bool FreeIkSubscriptions = false;
    }
}
