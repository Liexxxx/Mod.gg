﻿using Delusion.Classes;
using Delusion.Classes.CatagoryManager;
using System;
using static Delusion.Classes.CatagoryManager.CatagoryData_;
using static Delusion.Menu.Config;
using static Delusion.Menu.Main;
using MMods = Delusion.Mods.Movement.Mods;
using OPMods = Delusion.Mods.Overpowered.Mods;
using PMods = Delusion.Mods.Player.Mods;
using SMods = Delusion.Mods.Safety.Mods;
using WMods = Delusion.Mods.World.Mods;

namespace Delusion.Menu
{
    public class Buttons
    {
        public static ButtonInfo CreateButton(string ButtonText, Action Method, bool Toggable, bool Pre_enabled, string Description, Catagories Catagory)
        {
            ButtonInfo Output =
                new ButtonInfo
                {
                    buttonText = ButtonText,
                    method = Method,
                    isTogglable = Toggable,
                    enabled = Pre_enabled,
                    toolTip = Description,
                    Catagory = Catagory
                };
            return Output;
        }
        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[] { // Main Mods [0]
                CreateButton("Settings", ()=> CatagoryHandeler.SwitchCatagory(CatagoryData_.Catagories.Settings),false,false,"",CatagoryData_.Catagories.Main),
                CreateButton("Safety", ()=> CatagoryHandeler.SwitchCatagory(CatagoryData_.Catagories.Safety),false,false,"",CatagoryData_.Catagories.Main),
                CreateButton("Movement", ()=> CatagoryHandeler.SwitchCatagory(CatagoryData_.Catagories.Movment),false,false,"",CatagoryData_.Catagories.Main),
                CreateButton("Player", ()=> CatagoryHandeler.SwitchCatagory(CatagoryData_.Catagories.Player),false,false,"",CatagoryData_.Catagories.Main),
                CreateButton("World", ()=> CatagoryHandeler.SwitchCatagory(CatagoryData_.Catagories.World),false,false,"",CatagoryData_.Catagories.Main),
                CreateButton("Overpowered", ()=> CatagoryHandeler.SwitchCatagory(CatagoryData_.Catagories.Overpowered),false,false,"",CatagoryData_.Catagories.Main)
            },
            new ButtonInfo[] { // Settings [1]
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Settings),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Settings),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Settings),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Settings),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Settings),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Settings),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Settings),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Settings),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Settings),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Settings),
            },

            new ButtonInfo[] { // Safety [2]
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Safety),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Safety),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Safety),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Safety),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Safety),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Safety),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Safety),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Safety),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Safety),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Safety),
            },

            new ButtonInfo[] { // Movement [3]
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Movment),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Movment),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Movment),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Movment),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Movment),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Movment),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Movment),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Movment),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Movment),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Movment),
            },

            new ButtonInfo[] { // Player [4]
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Player),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Player),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Player),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Player),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Player),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Player),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Player),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Player),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Player),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Player),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Player),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Player),
            },

            new ButtonInfo[] { // World [5]
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.World),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.World),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.World),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.World),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.World),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.World),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.World),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.World),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.World),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.World),
            },

            new ButtonInfo[] { // Overpowered [6]
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Overpowered),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Overpowered),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Overpowered),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Overpowered),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Overpowered),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Overpowered),
                CreateButton("PlaceHolder",  delegate{ },false,false,"",CatagoryData_.Catagories.Overpowered),
                CreateButton("ToggablePlaceHolder",  delegate{ },true,false,"",CatagoryData_.Catagories.Overpowered),
            },
        };
    }
}
