﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace Delusion.Menu
{
    internal class Config
    {
        public static string MenuName = "Delusion";
        public static string ReturnHomeButtonText = "Home";
        public static string PreviousPageButtonText = "<";
        public static string NextPageButtonText = ">";
        public static string DisconnectButtonText = "Disconnect";

        public static Color MenuColor = TransparentMenu ? new Color32(139, 61, 159, 50) : new Color32(139, 61, 159, 255);
        public static Color ButtonColor = TransparentMenu ? new Color32(156, 61, 159, 50) : new Color32(156, 61, 159, 255);
        public static Color ButtonColor_Enabled = TransparentMenu ? new Color32(50, 30, 80, 50) : new Color32(50, 30, 80, 255);
        public static Color TextColor = Color.white;
        public static Color OutlineColor = new Color32(50, 30, 80, 255);

        public static Font currentFont = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;

        public static KeyCode keyboardButton = KeyCode.Q;

        public static Vector3 menuSize = new Vector3(0.1f, 1f, 0.95f); // Depth, width, height

        public static bool TransparentMenu = true;
        public static bool AutoRoundedMenu = false; 
        public static bool fpsCounter = true;
        public static bool disconnectButton = true;
        public static bool rightHanded;
        public static bool disableNotifications;

        public static int buttonsPerPage = 8;
    }
}
