﻿using UnityEngine;

namespace Delusion.Classes
{
    public class ColorChanger : MonoBehaviour
    {
        public void Start()
        {
            if (colors == null)
            {
                Destroy(this);
                return;
            }

            targetRenderer = GetComponent<Renderer>();

            if (colors.IsFlat())
            {
                Update();
                Destroy(this);
                return;
            }

            Update();
        }

        public void Update()
        {
            targetRenderer.enabled = !colors.transparent;

            if (colors.transparent)
                return;

        }

        public Renderer targetRenderer;
        public ExtGradient colors;
    }
}
