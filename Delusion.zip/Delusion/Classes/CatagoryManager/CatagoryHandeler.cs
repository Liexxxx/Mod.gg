﻿using Delusion.Menu;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static Delusion.Classes.CatagoryManager.CatagoryData_;

namespace Delusion.Classes.CatagoryManager
{
    internal class CatagoryHandeler
    {
        public static void SwitchCatagory(CatagoryData_.Catagories CatagoryToSwitchTo, bool MainPage = false)
        {
            if (!MainPage)
            {
                switch (CatagoryToSwitchTo)
                {
                    case CatagoryData_.Catagories.Settings:
                        Main.buttonsType = 1; Main.pageNumber = 0;
                        break;
                    case CatagoryData_.Catagories.Safety:
                         Main.buttonsType = 2; Main.pageNumber = 0;
                        break;
                    case CatagoryData_.Catagories.Movment:
                        Main.buttonsType = 3; Main.pageNumber = 0;
                        break;
                    case CatagoryData_.Catagories.Player:
                         Main.buttonsType = 4; Main.pageNumber = 0;
                        break;
                    case CatagoryData_.Catagories.World:
                        Main.buttonsType = 5; Main.pageNumber = 0;
                        break;
                    case CatagoryData_.Catagories.Overpowered:
                         Main.buttonsType = 6; Main.pageNumber = 0;
                        break;
                }
            }
            else
            {
                Main.buttonsType = 0; Main.pageNumber = 0;
            }
        }
        public static ButtonInfo[] FindButtonsUnderCatagory(Catagories category, int pageNumber)
        {
            int buttonsPerPage = Config.buttonsPerPage;

            List<ButtonInfo> list = new List<ButtonInfo>();

            foreach (ButtonInfo[] buttons in Buttons.buttons)
            {
                foreach (ButtonInfo button in buttons)
                {
                    if (button.Catagory == category)
                    {
                        list.Add(button);
                    }
                }
            }

            // Apply paging
            return list
                .Skip(pageNumber * buttonsPerPage)
                .Take(buttonsPerPage)
                .ToArray();
        }
    }
}
