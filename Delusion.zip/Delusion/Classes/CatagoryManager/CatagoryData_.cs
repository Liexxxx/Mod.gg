﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Delusion.Classes.CatagoryManager
{
    public class CatagoryData_
    {
        public enum Catagories
        {
            Main,
            Settings,
            Safety,
            Movment,
            Player,
            World,
            Overpowered
        }
        public static Catagories CurrentCatagory = Catagories.Settings;
        public static int NumberOfCatagories = 6;
    }
}
