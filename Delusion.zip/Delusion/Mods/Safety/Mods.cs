﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Delusion.Mods.Safety
{
    internal class Mods
    {
    }
}
