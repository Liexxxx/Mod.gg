﻿namespace Delusion
{
    public class PluginInfo
    {
        public const string GUID = "org.vivet.gorillatag.menutemplate";
        public const string Name = "Vivet Temp";
        public const string Description = "Based of @goldentrophy's temp!";
        public const string Version = "1.0.0";
    }
}
